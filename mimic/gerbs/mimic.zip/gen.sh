!/bin/bash
mv mimic-Edge_Cuts.gbr mimic.gko
rm mimic.zip 
zip mimic.zip *
