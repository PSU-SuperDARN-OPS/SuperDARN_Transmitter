#!/bin/bash
mv couplermod-Edge_Cuts.gbr couplermod.gko
rm couplermod.zip 
zip couplermod.zip *
