!/bin/bash
mv driveramp-Edge_Cuts.gbr driveramp.gko
rm driveramp.zip 
zip driveramp.zip *
