#!/bin/bash
mv driveramp-Inner1_Cu.gbr driveramp.g2l
mv driveramp-Inner2_Cu.gbr driveramp.g3l
mv driveramp-Edge_Cuts.gbr driveramp.gko
rm driveramp.zip
zip driveramp.zip *
